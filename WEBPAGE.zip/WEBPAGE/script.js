function spsh(){

	var end=1;
	var pass1=prompt('Password:','');
	while (end<3) {
		if (pass1.toLowerCase()=="pwd") {
			window.open('http://www.spearshot.com/random');
			break;
		}
		end+=1;
		pass1=prompt('Access Denied\nVersuch Nr: '+end,'');
	}
	if (pass1.toLowerCase()!="pwd" & end ==3)
	return "";
}

/*function wind(x){
	switch(x){
		case "ggl":
			window.open('http://www.google.com');
			break;
	}
}*/

function ggl(){
	window.open('http://www.google.com');
}

function wa(){
	window.open('https://www.wolframalpha.com');
}

function knx(){
	window.open('http://www.kinox.me');
}

function bs(){
	window.open('http://www.bs.to');
}

function yt(){
	window.open('http://www.youtube.com');
}

function twtch(){
	window.open('http://www.twitch.tv');
}
